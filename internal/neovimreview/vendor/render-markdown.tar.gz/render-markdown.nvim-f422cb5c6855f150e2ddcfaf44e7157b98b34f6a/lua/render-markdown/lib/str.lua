---@class render.md.Str
local M = {}

---@param s string
---@param sep string
---@param trimempty boolean
---@return string[]
function M.split(s, sep, trimempty)
    return vim.split(s, sep, { plain = true, trimempty = trimempty })
end

---@param s string
---@param i integer 1-based inclusive
---@param j integer 1-based inclusive
---@return string
function M.sub(s, i, j)
    local bytes = vim.str_utf_pos(s)
    local col = 1
    local result = ''
    for k, start_byte in ipairs(bytes) do
        local end_byte = k < #bytes and bytes[k + 1] - 1 or #s
        local char = s:sub(start_byte, end_byte)
        local width = M.width(char)
        if col >= i and col + width - 1 <= j then
            result = result .. char
        end
        col = col + width
    end
    return result
end

---number of a specific character at the start of the string
---@param s string
---@param ch string
---@return integer
function M.chars(s, ch)
    local match = s:match('^%s*(' .. vim.pesc(ch) .. '+)')
    return match and #match or 0
end

---@param s? string
---@return integer
function M.width(s)
    return s and vim.fn.strdisplaywidth(s) or 0
end

---@param line? render.md.mark.Line
---@return integer
function M.line_width(line)
    local result = 0
    for _, text in ipairs(line or {}) do
        result = result + M.width(text[1])
    end
    return result
end

---@param pos 'start'|'end'
---@param s string
---@return integer
function M.spaces(pos, s)
    local pattern = pos == 'start' and '^%s*' or '%s*$'
    local from, to = s:find(pattern)
    return (from and to) and to - from + 1 or 0
end

---@param n integer
---@return string
function M.pad(n)
    return n > 0 and (' '):rep(n) or ''
end

return M
